package com.example.chatchatprofile;

public class G {

    public static String nickName;
    public static String porfileUrl;
}
